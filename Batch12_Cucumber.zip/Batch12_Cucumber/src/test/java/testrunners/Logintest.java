package testrunners;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;


import pages.DarazHomePage;
import pages.DarazLoginPage;
import utilities.DriverSetup;

public class Logintest extends DriverSetup {
	DarazHomePage darazHomePage;
	DarazLoginPage darazLoginPage;
	
	@Test(priority = 0, description = "Home Page Loading Test with base URL")
	public void testHomePageUrl() {
		darazHomePage = new DarazHomePage();
		getDriver().get("https://www.daraz.com.bd/");
		assertEquals(getDriver().getCurrentUrl(), "https://www.daraz.com.bd/");
	}
	
	@Test
	public void testHomePageTitle() {
		darazHomePage = new DarazHomePage();
		getDriver().get("https://www.daraz.com.bd/");
		assertEquals(getDriver().getTitle(), "Online Shopping in Bangladesh: Order Now from Daraz.com.bd");	

	}

	@Test
	public void loginTest() {
		getDriver().get("https://www.daraz.com.bd/");
		darazLoginPage = darazHomePage.clickONLoginButton();
//		darazLoginPage.enterUsername("01888695");
//		darazLoginPage.enterPassword("Password");
		darazLoginPage.doLogIn("018886959", "pass");
		darazLoginPage.cliONLoginButton();
		assertEquals(getDriver().getTitle(), "Daraz.com.bd: Online Shopping Bangladesh - Mobiles, Tablets, Home Appliances, TV, Audio &amp;");

	}

}
